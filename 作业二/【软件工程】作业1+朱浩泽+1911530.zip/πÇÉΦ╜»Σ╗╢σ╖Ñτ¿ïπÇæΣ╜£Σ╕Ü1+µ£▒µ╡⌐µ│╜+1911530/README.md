# 项目路径

```tree
.
├── MaxSet.py         项目主体
├── PylintConfig.conf   Pylint配置文件
├── TestResult.txt  单元测试结果
├── my_coverage_result   路径覆盖率报告（点击index.html）
│   ├── MaxSet_py.html
│   ├── coverage_html.js
│   ├── favicon_32.png
│   ├── index.html  （点击查看路径覆盖率报告）
│   ├── keybd_closed.png
│   ├── keybd_open.png
│   ├── status.json
│   ├── style.css
│   └── try_unittest_py.html
├── try_profile.py  测试样例及测试函数
├── try_pylint.py  代码格式和风格测试
├── try_unittest.py  性能测试文件
└──【软件工程】作业报告+朱浩泽+1911530.pdf  实验报告
```

